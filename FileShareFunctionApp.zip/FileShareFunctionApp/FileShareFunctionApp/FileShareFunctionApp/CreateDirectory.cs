﻿using System;
using System.Collections.Generic;
using System.Text;
using Azure.Storage;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Microsoft.Extensions.Logging;

namespace FileShareFunctionApp
{
    public class CreateDirectory
    {
        public string connectionString;
        public string fileShareName;
        public ILogger log;

        public CreateDirectory(ILogger logg)
        {
            connectionString = Environment.GetEnvironmentVariable("StorageAccConnectionString");
            fileShareName = Environment.GetEnvironmentVariable("StorageAccFileShare");
            log = logg;

        }


        public string CreateDirectoryInFileShare(string directoryName)
        {
            try
            {
                // Get a reference to a share named "sample-share" and then create it
                ShareClient share = new ShareClient(connectionString, fileShareName);
                //share.Create();

                // Get a reference to a directory named "sample-dir" and then create it
                ShareDirectoryClient directory = share.GetDirectoryClient(directoryName);
                Azure.Response<ShareDirectoryInfo> response = directory.Create();

                log.LogInformation(directoryName +" Directory created in the file share successfully!");
                return response.GetRawResponse().Status.ToString();


            }
            catch(Azure.RequestFailedException ex)
            {
                log.LogError("Error while creating the Directory! " + ex.Message);
                return ex.Status.ToString();
            }
            catch(Exception ee)
            {
                return ee.Message;
            }


        }

    }
}
